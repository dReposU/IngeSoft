# Pago Ya — Frontend

Interfaz web del asistente de gastos. Es un sitio **estático** (HTML, CSS y JavaScript,
sin framework ni build) que consume la API del backend. Permite iniciar sesión, hacerle
preguntas al asistente en lenguaje natural y ver un gráfico de gasto por categoría que
se actualiza solo.

![HTML5](https://img.shields.io/badge/HTML5-E34F26?logo=html5&logoColor=white)
![CSS3](https://img.shields.io/badge/CSS3-1572B6?logo=css3&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?logo=javascript&logoColor=black)
![Chart.js](https://img.shields.io/badge/Chart.js-FF6384?logo=chartdotjs&logoColor=white)
![Netlify](https://img.shields.io/badge/Netlify-00C7B7?logo=netlify&logoColor=white)

**Autor:** Henry Antonio Mendoza Puerta

**Demo en vivo:**

- Aplicación (este frontend): https://pagoya-app.netlify.app
- API (backend): https://pagoya-backend.onrender.com

---

## Tabla de contenido

1. [Arquitectura](#arquitectura)
2. [Características](#características)
3. [Estructura](#estructura)
4. [Requisitos](#requisitos)
5. [Ejecutar en local](#ejecutar-en-local)
6. [Configuración](#configuración)
7. [Cómo funciona](#cómo-funciona)
8. [Despliegue en Netlify](#despliegue-en-netlify)
9. [Notas](#notas)

---

## Arquitectura

![Arquitectura del sistema](img/arquitectura.png)

---

## Características

- **Login por correo y contraseña** contra el backend.
- **Sesión persistente**: si recargas la página, sigues dentro (se guarda en `localStorage`). Incluye botón **Salir**.
- **Asistente en lenguaje natural**: escribes una pregunta y muestra la respuesta.
- **Gráfico de gasto por categoría** (Chart.js): siempre visible y se actualiza tras cada operación.
- **Saludo según la hora** (buenos días / tardes / noches) con el nombre del asistente.

---

## Estructura

```
frontend/
├── index.html    Estructura de la página (login + asistente)
├── styles.css    Estilos
├── script.js     Lógica (login, preguntar, gráfico, sesión)
└── README.md
```

---

## Requisitos

- Un navegador moderno (Chrome, Edge, Firefox, Brave).
- El **backend en marcha**. Repositorio del backend: https://github.com/hampcodes/pagoya-asistente
- Visual Studio Code con la extensión **Live Server** instalada.

---

## Ejecutar en local

Se usa la extensión **Live Server** de Visual Studio Code (no abras el archivo con doble
clic, porque el navegador bloquea las peticiones desde `file://`).

1. En VS Code, abre el panel de Extensiones e instala **Live Server** (de Ritwick Dey).
2. Abre el archivo `index.html`, haz clic derecho y elige **"Open with Live Server"**.
3. Se abrirá en el navegador (por ejemplo `http://127.0.0.1:5500`).

Asegúrate de que el backend esté corriendo en `http://127.0.0.1:8000`.

---

## Configuración

La configuración está al inicio de `script.js`. La URL del backend se elige **sola**:
en local usa `localhost`, y ya publicado usa el backend de Render.

```js
// En local usa el backend local; ya publicado, usa el de Render.
const esLocal = location.hostname === "localhost" || location.hostname === "127.0.0.1";
const BACKEND = esLocal ? "http://127.0.0.1:8000" : "https://pagoya-backend.onrender.com";

// Nombre del asistente (cámbialo por el que quieras)
const ASISTENTE = "PagoYaBot";
```

- Backend en producción: **https://pagoya-backend.onrender.com**
- Si tu backend tiene otra URL, cámbiala en esa línea.

---

## Cómo funciona

1. **Login**: envía `correo` y `clave` a `POST /login`. Si es correcto, guarda el id del
   usuario y muestra el panel del asistente.
2. **Preguntar**: envía `{ texto, usuario_id }` a `POST /preguntar` y muestra la respuesta.
3. **Gráfico**: pide `GET /grafico/{usuario_id}` y dibuja un gráfico de barras. Se actualiza
   al entrar y después de cada operación.
4. **Sesión**: el id del usuario se guarda en `localStorage`, así que al recargar sigues dentro.
   El botón **Salir** lo borra y vuelve al login.

Preguntas que puedes escribir, por ejemplo:

- "¿cuánto gasté en total?"
- "mi gasto por categoría"
- "mis últimos gastos"
- "registra 50 en comida"

---

## Despliegue en Netlify

Es un sitio estático: no hay build. Incluye un `netlify.toml` con `publish = "."`
para que Netlify **encuentre el `index.html`** (si no, a veces "no detecta la página").

**Opción A — desde GitHub (recomendada):**
1. En Netlify: **Add new site → Import from Git** y conecta el repo del frontend.
2. En *Build settings*:
   - **Branch to deploy:** `main`
   - **Base directory:** déjalo **vacío** (si el `index.html` está en la raíz del repo).
     Si el frontend está dentro de una subcarpeta del repo, pon ahí el nombre (ej. `frontend`).
   - **Build command:** vacío · **Publish directory:** `.`
3. Deploy. Netlify te dará una URL pública.

**Opción B — manual (la más simple):**
- **Add new site → Deploy manually** y arrastra la carpeta `frontend`.

> El `netlify.toml` ya define `publish = "."`, así que normalmente con dejar el Base
> directory vacío es suficiente.

---

## Notas

- **Chart.js** se carga por CDN desde `index.html`, así que se necesita conexión a internet
  para que el gráfico se muestre.
- El backend tiene CORS abierto (`allow_origins=["*"]`), por eso el frontend puede llamarlo
  desde otro dominio (Netlify → Render) sin problema.
