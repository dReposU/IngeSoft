// En local usa el backend local; ya publicado (Netlify), usa el de Render.
const esLocal = location.hostname === "localhost" || location.hostname === "127.0.0.1";
const BACKEND = esLocal ? "http://127.0.0.1:8000" : "https://pagoya-backend.onrender.com";

// Nombre del asistente (cambialo por el que quieras)
const ASISTENTE = "PagoYaBot";

// Elementos de la pagina (cada uno con un nombre claro)
const inputCorreo = document.getElementById("correo");
const inputClave  = document.getElementById("clave");
const loginMsg    = document.getElementById("loginMsg");
const cajaLogin   = document.getElementById("login");
const cajaChat    = document.getElementById("chat");
const saludo      = document.getElementById("saludo");
const inputTexto  = document.getElementById("texto");
const respuesta   = document.getElementById("respuesta");
const canvas      = document.getElementById("grafico");
const btnEnviar   = document.getElementById("enviar");

let idUsuario = null;
let grafico = null;

// Muestra el panel del asistente para un usuario ya identificado
const mostrarPanel = (id) => {
  idUsuario = id;
  cajaLogin.hidden = true;
  cajaChat.hidden = false;
  const hora = new Date().getHours();
  let saludoHora = "Buenas noches";
  if (hora < 12) saludoHora = "Buenos días";
  else if (hora < 19) saludoHora = "Buenas tardes";
  saludo.textContent = saludoHora + ". Soy tu asistente " + ASISTENTE + ". ¿En qué te puedo ayudar?";
  graficoPorDefecto();
};

// ---- Login (por correo) ----
document.getElementById("entrar").addEventListener("click", async () => {
  const res = await fetch(BACKEND + "/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ correo: inputCorreo.value.trim(), clave: inputClave.value })
  });
  const data = await res.json();
  if (!data.ok) {
    loginMsg.textContent = "Correo o contraseña incorrectos.";
    return;
  }
  localStorage.setItem("idUsuario", data.id);   // guarda la sesion (sigue dentro aunque se recargue)
  mostrarPanel(data.id);
});

// ---- Salir ----
document.getElementById("salir").addEventListener("click", () => {
  localStorage.removeItem("idUsuario");
  location.reload();
});

// ---- Preguntar al asistente ----
const preguntar = async () => {
  const texto = inputTexto.value.trim();
  if (!texto || btnEnviar.disabled) return;        // ignora si esta vacio o ya esta procesando

  // Mostrar "procesando" y bloquear el boton mientras espera la respuesta
  respuesta.textContent = "El asistente está procesando…";
  respuesta.classList.add("procesando");
  btnEnviar.disabled = true;

  try {
    const res = await fetch(BACKEND + "/preguntar", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ texto, usuario_id: idUsuario })
    });
    const data = await res.json();
    respuesta.textContent = data.respuesta;
    inputTexto.value = "";
    if (data.grafico) pintarGrafico(data.grafico);   // gráfico que pidió (categoría, mes…)
    else graficoPorDefecto();                          // si no, refresca el de por categoría
  } catch (e) {
    respuesta.textContent = "No se pudo conectar con el servidor. Intenta de nuevo (puede estar despertando).";
  } finally {
    respuesta.classList.remove("procesando");
    btnEnviar.disabled = false;     // vuelve a habilitar el boton
  }
};

btnEnviar.addEventListener("click", preguntar);
inputTexto.addEventListener("keydown", (e) => { if (e.key === "Enter") preguntar(); });

// ---- Grafico: pinta unos datos (titulo, labels, valores) ----
const pintarGrafico = (g) => {
  document.getElementById("tituloGrafico").textContent = g.titulo;
  if (grafico) {                    // si ya existe, solo actualizamos sus datos
    grafico.data.labels = g.labels;
    grafico.data.datasets[0].data = g.valores;
    grafico.update();
    return;
  }
  grafico = new Chart(canvas, {
    type: "bar",
    data: { labels: g.labels, datasets: [{ data: g.valores, backgroundColor: "#1f4e79" }] },
    options: { plugins: { legend: { display: false } }, scales: { y: { beginAtZero: true } } }
  });
};

// Trae del backend el grafico por defecto: gasto por categoria
const graficoPorDefecto = async () => {
  const g = await (await fetch(BACKEND + "/grafico/" + idUsuario)).json();
  pintarGrafico({ titulo: "Gasto por categoría", labels: g.labels, valores: g.valores });
};

// Al cargar la pagina: si ya hay una sesion guardada, muestra el asistente directo (no vuelve al login)
const idGuardado = localStorage.getItem("idUsuario");
if (idGuardado) mostrarPanel(Number(idGuardado));
