# Pago Ya — Backend

Asistente de control de gastos con IA. El usuario inicia sesión y pregunta en
**lenguaje natural** ("¿cuánto gasté?", "registra 50 en comida"); una IA decide qué
consulta ejecutar en la base de datos y responde con una frase. Algunas respuestas
incluyen los datos para un gráfico de gasto por categoría.

![Python](https://img.shields.io/badge/Python-3776AB?logo=python&logoColor=white)
![FastAPI](https://img.shields.io/badge/FastAPI-009688?logo=fastapi&logoColor=white)
![Uvicorn](https://img.shields.io/badge/Uvicorn-2C2C2C)
![SQLite](https://img.shields.io/badge/SQLite-003B57?logo=sqlite&logoColor=white)
![PostgreSQL](https://img.shields.io/badge/PostgreSQL-4169E1?logo=postgresql&logoColor=white)
![Ollama](https://img.shields.io/badge/Ollama-000000?logo=ollama&logoColor=white)
![OpenAI](https://img.shields.io/badge/OpenAI-412991?logo=openai&logoColor=white)
![Render](https://img.shields.io/badge/Render-46E3B7?logo=render&logoColor=black)

**Autor:** Henry Antonio Mendoza Puerta

**Demo en vivo:**

- Aplicación (frontend): https://pagoya-app.netlify.app
- API (backend): https://pagoya-backend.onrender.com — documentación: https://pagoya-backend.onrender.com/docs

---

## Tabla de contenido

1. [Arquitectura](#arquitectura)
2. [Características](#características)
3. [Estructura](#estructura)
4. [Requisitos](#requisitos)
5. [Ejecutar en local](#ejecutar-en-local)
6. [Variables de entorno](#variables-de-entorno)
7. [Cómo funciona](#cómo-funciona)
8. [Preguntas que entiende el asistente](#preguntas-que-entiende-el-asistente)
9. [Endpoints de la API](#endpoints-de-la-api)
10. [Usuarios de prueba](#usuarios-de-prueba)
11. [Base de datos](#base-de-datos)
12. [Despliegue en Render](#despliegue-en-render)
13. [Frontend](#frontend)

---

## Arquitectura

![Arquitectura del sistema](img/arquitectura.png)

---

## Características

- **Login por correo**: cada usuario ve solo sus gastos.
- **Asistente con IA**: entiende lenguaje natural y elige la función correcta.
- **4 acciones**: total gastado, gasto por categoría, últimos gastos y registrar un gasto.
- **Base de datos automática**: SQLite en local (no se instala nada) y PostgreSQL en Render,
  con el mismo código (SQL estándar). Crea las tablas y carga los datos de ejemplo al arrancar.
- **Listo para desplegar** en Render (incluye `render.yaml`).

---

## Estructura

```
backend/
├── main.py            API completa (login, asistente, gráfico, base de datos)
├── requirements.txt   Dependencias
├── render.yaml        Configuración de despliegue en Render (Blueprint)
├── .env.example       Ejemplo de variables de entorno (copiar a .env)
├── .gitignore         Ignora .env, *.db, venv, etc.
└── README.md
```

---

## Requisitos

- Python 3.10 o superior.
- Una clave de IA: **Ollama Cloud** (https://ollama.com/settings/keys) o **OpenAI**.
- No se necesita instalar ninguna base de datos para trabajar en local.

---

## Ejecutar en local

```bash
# 1) Crear y activar el entorno virtual
python -m venv venv
# Windows:        venv\Scripts\activate
# macOS / Linux:  source venv/bin/activate

# 2) Instalar dependencias
pip install -r requirements.txt

# 3) Crear el archivo .env (copiar el ejemplo) y poner la clave
#    OLLAMA_API_KEY=tu_clave        (o OPENAI_API_KEY=...)

# 4) Arrancar
uvicorn main:app --reload
```

- API: **http://127.0.0.1:8000**
- Documentación interactiva (Swagger): **http://127.0.0.1:8000/docs**

La base SQLite se crea sola con los datos de ejemplo la primera vez.

---

## Variables de entorno

Se definen en un archivo `.env` (no se sube a Git).

| Variable | Obligatoria | Descripción |
|----------|-------------|-------------|
| `OLLAMA_API_KEY` | Sí (si usas Ollama) | Clave de Ollama Cloud. |
| `OPENAI_API_KEY` | Sí (si usas OpenAI) | Clave de OpenAI (descomentar su línea en `main.py`). |
| `DATABASE_URL`   | No en local | Si existe, usa PostgreSQL; si no, usa SQLite. En Render se conecta automáticamente. |

---

## Cómo funciona

El endpoint `/preguntar` resuelve cada pregunta en tres pasos:

1. **La IA elige la función**: responde un JSON, por ejemplo
   `{"funcion": "por_categoria"}` o
   `{"funcion": "registrar_gasto", "categoria": "comida", "monto": 50}`.
2. **Se ejecuta esa función** en la base de datos, filtrada por el usuario logueado.
3. **La IA redacta la respuesta** final en una frase clara.

El gráfico se obtiene aparte con `/grafico/{usuario_id}` y se actualiza tras cada operación.

---

## Preguntas que entiende el asistente

El asistente atiende estas cuatro intenciones. Entiende variantes; no hace falta escribirlo exacto.

| Función | Qué hace | Ejemplos de preguntas |
|---------|----------|-----------------------|
| `mi_total` | Suma todo lo que ha gastado | "¿cuánto gasté en total?" · "mi total" |
| `gasto_promedio` | El promedio de sus gastos | "mi promedio" · "cuánto gasto en promedio" |
| `por_categoria` | Gasto por categoría (gráfico) | "mi gasto por categoría" · "¿en qué gasto más?" |
| `gasto_por_mes` | Gasto por mes (gráfico) | "mi gasto por mes" · "gasto mensual" |
| `gasto_de_categoria` | Gasto de una sola categoría, mes a mes (gráfico) | "cuánto gasté en comida" · "gráfico de salud" |
| `gastos_mayores` | Sus gastos más grandes (ranking) | "mis gastos más grandes" · "ranking de mis gastos" |
| `ultimos_gastos` | Sus movimientos más recientes | "mis últimos gastos" · "¿qué compré?" |
| `buscar` | Busca gastos por una palabra | "busca pasaje" · "gastos que digan mensual" |
| `registrar_gasto` | Anota un gasto nuevo (con la fecha de hoy) | "registra 50 en comida" · "anota 30 en ocio" |

---

## Endpoints de la API

| Método | Ruta | Body / Parámetros | Respuesta |
|--------|------|-------------------|-----------|
| `POST` | `/login` | `{ "correo": "...", "clave": "..." }` | `{ "ok": true, "id": 5, "nombre": "Sofia Gomez" }` |
| `POST` | `/preguntar` | `{ "texto": "...", "usuario_id": 5 }` | `{ "respuesta": "..." }` |
| `GET`  | `/grafico/{usuario_id}` | — | `{ "labels": [...], "valores": [...] }` |

Ejemplo con `curl`:

```bash
# Login
curl -X POST http://127.0.0.1:8000/login \
  -H "Content-Type: application/json" \
  -d '{"correo":"sofia@mail.com","clave":"1234"}'

# Preguntar
curl -X POST http://127.0.0.1:8000/preguntar \
  -H "Content-Type: application/json" \
  -d '{"texto":"mi gasto por categoria","usuario_id":5}'
```

---

## Usuarios de prueba

Todos con la contraseña **`1234`**:

| Correo | Nombre |
|--------|--------|
| `ana@mail.com`   | Ana Torres |
| `luis@mail.com`  | Luis Ramos |
| `maria@mail.com` | Maria Flores |
| `pedro@mail.com` | Pedro Diaz |
| `sofia@mail.com` | Sofia Gomez |

> Es un login de demostración (sin encriptar, sin sesiones): sirve para aprender, no para producción.

---

## Base de datos

Tres tablas relacionadas por claves foráneas: `usuarios`, `categorias` y `gastos`.
El mismo código funciona en dos motores gracias a SQL estándar:

- **Local → SQLite** (no se instala nada; el archivo se crea solo).
- **Render → PostgreSQL** (cuando existe `DATABASE_URL`).

Los datos de ejemplo (5 usuarios, 8 categorías, 15 gastos) se cargan automáticamente
la primera vez que arranca con la base vacía.

---

## Despliegue en Render

El archivo `render.yaml` (Blueprint) crea de una sola vez un PostgreSQL gratis y el Web Service.

1. Subir esta carpeta `backend` como repositorio a GitHub (el `.env` no se sube).
2. En Render: **New + → Blueprint** y conectar el repo (lee `render.yaml`).
3. En el servicio → **Environment** → agregar `OLLAMA_API_KEY` con la clave.
4. Deploy. Se obtiene una URL tipo `https://pagoya-backend.onrender.com`
   (probar en `https://tu-url.onrender.com/docs`).

> En el plan gratis, la primera petición tras un rato de inactividad tarda ~30-50 s (arranque en frío).

---

## Frontend

El frontend (HTML, CSS y JavaScript, en la carpeta `../frontend`) consume esta API.
Tras desplegar el backend, cambiar en su `script.js` la línea
`const BACKEND = "http://127.0.0.1:8000"` por la URL de Render.
