# ============================================================
#  PAGO YA - Asistente de gastos (BACKEND con FastAPI)
#
#  Misma base de codigo en LOCAL y en RENDER:
#   - LOCAL: usa SQLite (viene con Python, no se instala nada).
#   - RENDER: si existe DATABASE_URL, usa PostgreSQL.
#  Las consultas son SQL estandar; solo cambia el conector.
#
#  Al arrancar, si la BD esta vacia, crea las tablas y carga los
#  datos de ejemplo automaticamente.
#
#  Ejecutar:  uvicorn main:app --reload
# ============================================================
import os, json, sqlite3
from datetime import date
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from openai import OpenAI
from dotenv import load_dotenv

load_dotenv()

# Si hay DATABASE_URL (Render) -> PostgreSQL. Si no -> SQLite (local).
DATABASE_URL = os.environ.get("DATABASE_URL")
USA_POSTGRES = bool(DATABASE_URL)
if USA_POSTGRES:
    import psycopg2

# Ruta del archivo SQLite: SIEMPRE en la carpeta del backend (sin importar desde dónde se ejecute uvicorn)
DB_SQLITE = os.path.join(os.path.dirname(__file__), "caso_demo_pagoya.db")

#client = OpenAI(api_key=os.environ.get("OPENAI_API_KEY"))
client = OpenAI(base_url="https://ollama.com/v1", api_key=os.environ.get("OLLAMA_API_KEY"))
#MODELO = "gpt-4o-mini"
#MODELO = "gpt-oss:120b"
MODELO = "gpt-oss:20b"

app = FastAPI()
app.add_middleware(CORSMiddleware, allow_origins=["*"], allow_methods=["*"], allow_headers=["*"])


def conectar():
    if USA_POSTGRES:
        return psycopg2.connect(DATABASE_URL)
    return sqlite3.connect(DB_SQLITE)

def consultar(sql, datos=()):
    # Las consultas se escriben con "?" (estilo SQLite). Postgres usa "%s",
    # asi que aqui lo cambiamos solo cuando toca. El resto del SQL es estandar.
    if USA_POSTGRES:
        sql = sql.replace("?", "%s")
    con = conectar()
    cur = con.cursor()
    cur.execute(sql, datos)
    filas = cur.fetchall() if cur.description else []   # SELECT devuelve filas; INSERT no
    con.commit()
    cur.close()
    con.close()
    return filas


def preguntar_ia(texto):
    r = client.chat.completions.create(model=MODELO, messages=[{"role": "user", "content": texto}])
    return r.choices[0].message.content.strip()


# ============================================================
#  CREA LAS TABLAS Y CARGA LOS DATOS DE EJEMPLO (solo la 1ra vez)
# ============================================================
USUARIOS = [
    ("Ana Torres",   "ana@mail.com",   "1234"),
    ("Luis Ramos",   "luis@mail.com",  "1234"),
    ("Maria Flores", "maria@mail.com", "1234"),
    ("Pedro Diaz",   "pedro@mail.com", "1234"),
    ("Sofia Gomez",  "sofia@mail.com", "1234"),
]
CATEGORIAS = [("Comida",), ("Transporte",), ("Servicios",), ("Ocio",),
              ("Salud",), ("Educacion",), ("Hogar",), ("Otros",)]
GASTOS = [
    (1, 1, "2024-08-03", 120, "Supermercado"),       (2, 2, "2024-08-10", 540, "Pasaje mensual"),
    (3, 1, "2024-09-01",  75, "Almuerzo"),           (1, 4, "2024-09-15", 600, "Concierto"),
    (4, 5, "2024-09-20", 250, "Farmacia"),           (5, 7, "2024-10-02", 480, "Muebles"),
    (2, 7, "2024-10-11", 900, "Refrigeradora"),      (3, 3, "2024-10-18",  60, "Internet"),
    (4, 1, "2024-11-05", 330, "Compras del mes"),    (5, 2, "2024-11-12", 700, "Mantenimiento auto"),
    (1, 6, "2024-11-20",  45, "Libros"),             (2, 4, "2024-12-01", 510, "Videojuego"),
    (3, 8, "2024-12-09", 200, "Varios"),             (4, 7, "2024-12-15", 150, "Decoracion"),
    (5, 5, "2025-01-04", 820, "Consulta medica"),
]

def inicializar_db():
    # El tipo del id auto-incremental cambia segun la base
    id_tipo = "SERIAL PRIMARY KEY" if USA_POSTGRES else "INTEGER PRIMARY KEY"
    consultar(f"CREATE TABLE IF NOT EXISTS usuarios (id {id_tipo}, nombre TEXT, correo TEXT, clave TEXT)")
    consultar(f"CREATE TABLE IF NOT EXISTS categorias (id {id_tipo}, nombre TEXT)")
    consultar(f"""CREATE TABLE IF NOT EXISTS gastos (id {id_tipo}, usuario_id INTEGER,
                  categoria_id INTEGER, fecha TEXT, monto REAL, descripcion TEXT)""")
    if consultar("SELECT COUNT(*) FROM usuarios")[0][0] == 0:     # solo si esta vacia
        for u in USUARIOS:
            consultar("INSERT INTO usuarios (nombre, correo, clave) VALUES (?, ?, ?)", u)
        for c in CATEGORIAS:
            consultar("INSERT INTO categorias (nombre) VALUES (?)", c)
        for g in GASTOS:
            consultar("INSERT INTO gastos (usuario_id, categoria_id, fecha, monto, descripcion) "
                      "VALUES (?, ?, ?, ?, ?)", g)

inicializar_db()


# ============================================================
#  LOGIN (por correo). Cada usuario vera solo SUS gastos.
# ============================================================
class Login(BaseModel):
    correo: str
    clave: str

@app.post("/login")
def login(d: Login):
    filas = consultar("SELECT id, nombre FROM usuarios WHERE correo = ? AND clave = ?",
                      (d.correo, d.clave))
    if filas:
        return {"ok": True, "id": filas[0][0], "nombre": filas[0][1]}
    return {"ok": False}


# ============================================================
#  LAS FUNCIONES DEL ASISTENTE (sobre los gastos del usuario)
# ============================================================
def mi_total(usuario_id):
    return consultar("SELECT SUM(monto) FROM gastos WHERE usuario_id = ?", (usuario_id,))

def por_categoria(usuario_id):
    return consultar("""SELECT c.nombre, SUM(g.monto)
                        FROM gastos g JOIN categorias c ON g.categoria_id = c.id
                        WHERE g.usuario_id = ? GROUP BY c.nombre ORDER BY 2 DESC""", (usuario_id,))

def ultimos_gastos(usuario_id):
    return consultar("""SELECT c.nombre, g.monto, g.fecha
                        FROM gastos g JOIN categorias c ON g.categoria_id = c.id
                        WHERE g.usuario_id = ? ORDER BY g.id DESC LIMIT 5""", (usuario_id,))

def registrar_gasto(usuario_id, categoria, monto):
    # LOWER(...) LIKE LOWER(...) = busca sin importar mayusculas, y es SQL estandar (sirve en ambas bases)
    cat = consultar("SELECT id FROM categorias WHERE LOWER(nombre) LIKE LOWER(?)", ('%' + categoria + '%',))
    if not cat:
        return f"No existe la categoria '{categoria}'."
    hoy = date.today().isoformat()                  # fecha actual, ej. "2026-06-26"
    consultar("""INSERT INTO gastos (usuario_id, categoria_id, fecha, monto, descripcion)
                 VALUES (?, ?, ?, ?, 'Registrado por el asistente')""",
              (usuario_id, cat[0][0], hoy, monto))
    return f"Gasto de {monto} registrado en {categoria}."

def gasto_promedio(usuario_id):
    return consultar("SELECT AVG(monto) FROM gastos WHERE usuario_id = ?", (usuario_id,))

def gastos_mayores(usuario_id):
    # ranking: sus 5 gastos mas grandes
    return consultar("""SELECT c.nombre, g.monto
                        FROM gastos g JOIN categorias c ON g.categoria_id = c.id
                        WHERE g.usuario_id = ? ORDER BY g.monto DESC LIMIT 5""", (usuario_id,))

def buscar(usuario_id, palabra):
    return consultar("""SELECT c.nombre, g.monto, g.descripcion
                        FROM gastos g JOIN categorias c ON g.categoria_id = c.id
                        WHERE g.usuario_id = ? AND LOWER(g.descripcion) LIKE LOWER(?)""",
                     (usuario_id, '%' + palabra + '%'))

def gasto_por_mes(usuario_id):
    # substr(fecha,1,7) = "AAAA-MM"; funciona en SQLite y Postgres (la fecha es texto)
    return consultar("""SELECT substr(fecha, 1, 7) AS mes, SUM(monto)
                        FROM gastos WHERE usuario_id = ? GROUP BY mes ORDER BY mes""", (usuario_id,))

def gasto_de_categoria(usuario_id, categoria):
    # gasto de UNA categoria, mes a mes (para pintar su grafico)
    return consultar("""SELECT substr(g.fecha, 1, 7) AS mes, SUM(g.monto)
                        FROM gastos g JOIN categorias c ON g.categoria_id = c.id
                        WHERE g.usuario_id = ? AND LOWER(c.nombre) LIKE LOWER(?)
                        GROUP BY mes ORDER BY mes""", (usuario_id, '%' + categoria + '%'))


# Instrucciones para la IA (texto multilinea, sin \n)
INSTRUCCIONES = """Eres un asistente de gastos. Elige UNA opcion y responde SOLO con su JSON, sin texto extra.

mi_total = cuanto gasto en total. Ejemplos: "cuanto gaste", "mi total". JSON: {"funcion": "mi_total"}
gasto_promedio = el promedio de sus gastos. Ejemplos: "mi promedio", "cuanto gasto en promedio". JSON: {"funcion": "gasto_promedio"}
por_categoria = cuanto gasta en cada categoria. Ejemplos: "mi gasto por categoria", "en que gasto mas". JSON: {"funcion": "por_categoria"}
gasto_por_mes = cuanto gasta en cada mes. Ejemplos: "mi gasto por mes", "gasto mensual". JSON: {"funcion": "gasto_por_mes"}
gasto_de_categoria = el gasto de UNA categoria, mes a mes. Ejemplos: "cuanto gaste en comida", "grafico de salud". JSON: {"funcion": "gasto_de_categoria", "categoria": "NOMBRE"}
gastos_mayores = sus gastos mas grandes (ranking). Ejemplos: "mis gastos mas grandes", "ranking de mis gastos". JSON: {"funcion": "gastos_mayores"}
ultimos_gastos = sus gastos mas recientes. Ejemplos: "mis ultimos gastos", "que compre". JSON: {"funcion": "ultimos_gastos"}
buscar = busca gastos por una palabra. Ejemplos: "busca pasaje", "gastos que digan mensual". JSON: {"funcion": "buscar", "palabra": "TEXTO"}
registrar_gasto = anota un gasto nuevo. Ejemplo: "registra 50 en comida". JSON: {"funcion": "registrar_gasto", "categoria": "NOMBRE", "monto": NUMERO}

Pregunta: """


class Pregunta(BaseModel):
    texto: str
    usuario_id: int

@app.post("/preguntar")
def preguntar(p: Pregunta):
    # 1) La IA elige una funcion segun la pregunta
    plan = preguntar_ia(INSTRUCCIONES + p.texto)

    # 2) Ejecutamos la funcion que eligio (simple: un if por cada una)
    try:
        # La IA a veces agrega texto antes/despues del JSON. Tomamos del primer "{"
        # (find) al ultimo "}" (rfind = buscar desde el final) para quedarnos solo con el JSON.
        inicio, fin = plan.find("{"), plan.rfind("}")
        datos = json.loads(plan[inicio:fin + 1])   # json.loads convierte ese texto en un diccionario
        funcion = datos["funcion"]
        if funcion == "registrar_gasto":
            resultado = registrar_gasto(p.usuario_id, datos["categoria"], datos["monto"])
        elif funcion == "buscar":
            resultado = buscar(p.usuario_id, datos["palabra"])
        elif funcion == "gasto_de_categoria":
            resultado = gasto_de_categoria(p.usuario_id, datos["categoria"])
        elif funcion == "por_categoria":
            resultado = por_categoria(p.usuario_id)
        elif funcion == "gasto_por_mes":
            resultado = gasto_por_mes(p.usuario_id)
        elif funcion == "gasto_promedio":
            resultado = gasto_promedio(p.usuario_id)
        elif funcion == "gastos_mayores":
            resultado = gastos_mayores(p.usuario_id)
        elif funcion == "ultimos_gastos":
            resultado = ultimos_gastos(p.usuario_id)
        else:
            resultado = mi_total(p.usuario_id)
    except Exception as error:
        return {"respuesta": f"No entendi la peticion. {error}", "grafico": None}

    # 3) Si la funcion es de grafico, preparamos los datos (titulo, labels y valores)
    grafico = None
    if funcion == "por_categoria":
        grafico = {"titulo": "Gasto por categoría",
                   "labels": [f[0] for f in resultado], "valores": [f[1] for f in resultado]}
    elif funcion == "gasto_por_mes":
        grafico = {"titulo": "Gasto por mes",
                   "labels": [f[0] for f in resultado], "valores": [f[1] for f in resultado]}
    elif funcion == "gasto_de_categoria":
        grafico = {"titulo": "Gasto en " + datos["categoria"],
                   "labels": [f[0] for f in resultado], "valores": [f[1] for f in resultado]}

    # 4) La IA redacta la respuesta en una frase
    try:
        respuesta = preguntar_ia(f"Pregunta: {p.texto}. Datos: {resultado}. "
                                 "Responde en una frase corta y clara en espanol.")
    except Exception:
        respuesta = str(resultado)
    return {"respuesta": respuesta, "grafico": grafico}


# El grafico (gasto por categoria) se muestra siempre y se actualiza tras cada operacion
@app.get("/grafico/{usuario_id}")
def grafico(usuario_id: int):
    filas = por_categoria(usuario_id)
    return {"labels": [fila[0] for fila in filas], "valores": [fila[1] for fila in filas]}
